package edu.curtin.saed.assignment2;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;



/**
 * This is demonstration code intended for you to modify. Currently, it sets up a rudimentary
 * JavaFX GUI with the basic elements required for the assignment.
 *
 * (There is an equivalent Swing version of this, which you can use if you have trouble getting
 * JavaFX as a whole to work.)
 *
 * You will need to use the GridArea object, and create various GridAreaIcon objects, to represent
 * the on-screen map.
 *
 * Use the startBtn, endBtn, statusText and textArea objects for the other input/output required by
 * the assignment specification.
 *
 * Break this up into multiple methods and/or classes if it seems appropriate. Promote some of the
 * local variables to fields if needed.
 */
public class App extends Application
{
    private List<Integer> gameDims;
    private List<Integer> startPos;
    private List<Integer> trophyPos;

    private List<TempItemData> tempItemData;
    private List<TempObstacleData> tempObstacleData;

    private List<String> plugins;
    private List<String> scripts;

    private List<List<GameObject>> objectMap;
    private List<GameObject> itemList; // Holds items and trophy only
    private List<List<GridAreaIcon>> fogMap;

    GridAreaIcon playerIcon;

    GridArea area;
    Button abilityBtn;
    Label statusText;
    TextArea inventoryTextArea;
    TextField localeInputField;
    Button applyBtn;
    Label dateLabel;

    private Image IMG_PERSON;
    private Image IMG_TROPHY;
    private Image IMG_ITEM;
    private Image IMG_OBSTACLE;
    private Image IMG_FOG;

    private long lastMoveTime = 0L;
    private long moveCooldown = 1000L;
    

    public static void main(String[] args)
    {
        launch();
    }

    @Override
    public void start(Stage stage)
    {
        ClassLoader cl = App.class.getClassLoader();
        IMG_PERSON   = new Image(cl.getResourceAsStream("person.png"), 64, 64, true, true);
        IMG_TROPHY   = new Image(cl.getResourceAsStream("trophy.png"), 64, 64, true, true);
        IMG_ITEM     = new Image(cl.getResourceAsStream("item.png"), 64, 64, true, true);
        IMG_OBSTACLE = new Image(cl.getResourceAsStream("obstacle.png"), 64, 64, true, true);
        IMG_FOG      = new Image(cl.getResourceAsStream("fog.png"), 64, 64, true, true);

        // Get data using DSL
        gameDims = List.of(10, 10);
        startPos = List.of(0, 0);
        trophyPos = List.of(9, 1);
        tempItemData = getTempItemData();
        tempObstacleData = getTempObstacleData();

        plugins = new ArrayList<>(
            List.of(
                "edu.curtin.gameplugins.Teleport", 
                "edu.curtin.gameplugins.Penalty", 
                "edu.curtin.gameplugins.Reveal"
            )
        );

        scripts = new ArrayList<String>();

        // #region UI_ELEMENTS
        // Set up the main "top-down" display area. 

        area = new GridArea(gameDims.get(0), gameDims.get(1));
        area.setStyle("-fx-background-color: #4D4D4D;");

        // Set up other key parts of the user interface. You'll also want to adjust this.
        abilityBtn = new Button("Special Ability");

        statusText = new Label("");
        inventoryTextArea = new TextArea();
        inventoryTextArea.appendText("Inventory:\n");
        
        localeInputField = new TextField();
        localeInputField.setPromptText("try fr-FR");
        localeInputField.setPrefColumnCount(8);
        applyBtn = new Button("Apply");
        dateLabel = new Label();

        statusText.setMaxWidth(Double.MAX_VALUE);
        statusText.setWrapText(true);
        HBox.setHgrow(statusText, Priority.ALWAYS);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        // #endregion

        // #region BUILD_GAME

        //different methods. check for things like proper list size and 
        //if object is already in pos before insertion
        //if no trophy or palyer pos
        // plugins and script/s (edu.curtin.gameplugins.Teleport)

        // Build UI Manager (stores UI stuff and locale stuff)
        UIManager uiManager = new UIManager(abilityBtn, 
                                            statusText, inventoryTextArea, 
                                            applyBtn, 
                                            stage, dateLabel);
        uiManager.refreshDateLabel();


        // Build map and list of items
        int rows = gameDims.get(0);
        int cols = gameDims.get(1);

        objectMap = new ArrayList<>();
        for (int i = 0; i < rows; i++) {
            List<GameObject> row = new ArrayList<>(cols);
            for (int j = 0; j < cols; j++) {
                row.add(null);
            }
            objectMap.add(row);
        }
        // Add Player, trophy, items and obstacles to map and GridArea.
        buildMap();

        // Build fog map
        fogMap = new ArrayList<>();
        for (int i = 0; i < rows; i++) {
            List<GridAreaIcon> row = new ArrayList<>(cols);
            // fill each row with nulls
            for (int j = 0; j < cols; j++) {
                row.add(null);
            }
            fogMap.add(row);
        }
        // Add fog to map and GridArea.
        buildFog();

        // Build Game Manager (API impl), stores UI Manager, inventory, etc
        GameManager gameManager = new GameManager(uiManager, area, 
                                                playerIcon, objectMap, 
                                                itemList, fogMap, IMG_OBSTACLE);

        // set up plugin/s
        loadPlugins(plugins, gameManager);




        // set up script/s




        // #endregion

        // #region BUTTONS
        abilityBtn.setOnAction((event) ->
        {
            gameManager.notifyButtonListeners();
            abilityBtn.setDisable(true);
            System.out.println("Ability button pressed");
        });
        applyBtn.setOnAction((event) ->
        {
            uiManager.applyLocaleFromTag(localeInputField.getText());
            System.out.println("Apply button pressed");
        });
        stage.setOnCloseRequest((event) ->
        {
            System.out.println("Close button pressed");
        });
        
        
        // #endregion
        
        // #region PLUMBING
        // Below is basically just the GUI "plumbing" (connecting things together).

        var toolbar = new ToolBar();
        toolbar.getItems().addAll(
            abilityBtn, 
            new Separator(), 
            statusText, spacer, 
            dateLabel,
            new Separator(), 
            localeInputField, 
            applyBtn
        );

        var splitPane = new SplitPane();
        splitPane.getItems().addAll(area, inventoryTextArea);
        splitPane.setDividerPositions(0.75);

        stage.setTitle("Maze Game");
        var contentPane = new BorderPane();
        contentPane.setTop(toolbar);
        contentPane.setCenter(splitPane);

        var scene = new Scene(contentPane, 1200, 800);
        scene.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastMoveTime < moveCooldown) {
                e.consume();
                return;
            }
            boolean moved = false;
            switch (e.getCode()) {
                case UP:
                    gameManager.makeMove(0, -1);
                    moved = true;
                    break;
                case DOWN:
                    gameManager.makeMove(0, 1);
                    moved = true;
                    break;
                case LEFT:
                    gameManager.makeMove(-1, 0);
                    moved = true;
                    break;
                case RIGHT:
                    gameManager.makeMove(1, 0);
                    moved = true;
                    break;
                default:
                    break;
            }
            if (moved) {
                lastMoveTime = currentTime;
                e.consume();
            }
        });
        stage.setScene(scene);
        stage.show();
        // #endregion
    }

    public void loadPlugins(List<String> pluginNames, GameManager gameManager) {
        for (String pluginName : pluginNames) {
            try {
                Class<?> cls = Class.forName(pluginName);

                Constructor<?> constructor = cls.getConstructor(ApiInterface.class);

                @SuppressWarnings("unused")
                PluginInterface pluginInstance = (PluginInterface) constructor.newInstance(gameManager);
            } catch (Exception e) {
                System.err.println("Failed to load plugin: " + pluginName);
                e.printStackTrace();
            }
        }
    }

    public void buildMap() {
        // objectMap
        // itemList
        // area
        // Check if not none (taken), and in bounds
        itemList = new ArrayList<>();

        // add trophy
        GridAreaIcon trophyIcon = new GridAreaIcon(
            trophyPos.get(0), 
            trophyPos.get(1), 
            0, 1, 
            IMG_TROPHY, 
            ""
        );
        area.getIcons().add(trophyIcon);
        Trophy trophy = new Trophy(trophyIcon);
        objectMap.get(trophyPos.get(0)).set(trophyPos.get(1), trophy);
        itemList.add(trophy);

        // add items to object map and item list and area
        /*
         * check if position filled before proceeding
         * must make a new icon for each entry in positions and add to area.
         * tf, at end of each entry in positions, create item, add to stuff.
         */
        for (TempItemData tempData : tempItemData) { 
            String name = tempData.name;
            List<List<Integer>> positions = tempData.positions;
            String message = tempData.message;

            for (List<Integer> pos : positions) {
                try {
                    // if object has already taken that spot, throw exception if out of bounds
                    if (objectMap.get(pos.get(0)).get(pos.get(1)) != null) {
                        continue;
                    }
                    if (pos.get(0) == startPos.get(0) && pos.get(1) == startPos.get(1)) {
                        continue;
                    }

                    // create icon
                    GridAreaIcon icon = new GridAreaIcon(
                        pos.get(0), 
                        pos.get(1), 
                        0, 1, 
                        IMG_ITEM, 
                        ""
                    );

                    // add icon to grid
                    area.getIcons().add(icon);
                    // create item
                    Item item = new Item(name, message, icon);
                    // add to object map
                    objectMap.get(pos.get(0)).set(pos.get(1), item);
                    // add to item list
                    itemList.add(item);
                } catch (IndexOutOfBoundsException e) { } // if coords out of bounds; skip
            }
        }

        // add obstacles to object map and area
        for (TempObstacleData tempData : tempObstacleData) { 
            List<String> requires = tempData.requires;
            List<List<Integer>> positions = tempData.positions;

            for (List<Integer> pos : positions) {
                try {
                    // if object has already taken that spot, throw exception if out of bounds
                    if (objectMap.get(pos.get(0)).get(pos.get(1)) != null) {
                        continue;
                    }
                    if (pos.get(0) == startPos.get(0) && pos.get(1) == startPos.get(1)) {
                        continue;
                    }

                    // create icon
                    GridAreaIcon icon = new GridAreaIcon(
                        pos.get(0), 
                        pos.get(1), 
                        0, 1, 
                        IMG_OBSTACLE, 
                        ""
                    );

                    // add icon to grid
                    area.getIcons().add(icon);
                    // create obstacle
                    Obstacle obstacle = new Obstacle(requires, icon);
                    // add to object map
                    objectMap.get(pos.get(0)).set(pos.get(1), obstacle);
                } catch (IndexOutOfBoundsException e) { } // if coords out of bounds; skip
            }
        }

        // add player
        // adding last because needs to appear over obstacles when bypassing
        playerIcon = new GridAreaIcon(
            startPos.get(0), 
            startPos.get(1), 
            0, 1, 
            IMG_PERSON, 
            ""
        );
        area.getIcons().add(playerIcon);
    }

    public void buildFog() {
        // just fill fog map with fog icons, adding to area
        // area, fogMap
        int startX = startPos.get(0);
        int startY = startPos.get(1);

        // remove fog icons on and around player
        for (int i = 0; i < fogMap.size(); i++) {
            for (int j = 0; j < fogMap.get(i).size(); j++) {

                GridAreaIcon icon = new GridAreaIcon(
                    i, j,
                    0, 1.0,
                    IMG_FOG,
                    ""
                );

                // no fog on or orthogonal to player
                int dx = Math.abs(i - startX);
                int dy = Math.abs(j - startY);
                if (dx + dy <= 1) {
                    icon.setShown(false);
                }

                fogMap.get(i).set(j, icon);

                area.getIcons().add(icon);
            }
        }
    }

    public List<TempItemData> getTempItemData() {

        List<TempItemData> tempItemDataList = new ArrayList<>();

        List<List<Integer>> positions = new ArrayList<>(
            List.of(
                new ArrayList<>(List.of(5, 5)),
                new ArrayList<>(List.of(6, 7))
            )
        );
        TempItemData tempItemData = new TempItemData("item.wooden_sword", positions, "This is a msg for sword.");
        tempItemDataList.add(tempItemData);

        positions = new ArrayList<>(
            List.of(
                new ArrayList<>(List.of(8, 8)),
                new ArrayList<>(List.of(6, 9))
            )
        );
        tempItemData = new TempItemData("item.wooden_shield", positions, "This is a msg for shield.");
        tempItemDataList.add(tempItemData);

        positions = new ArrayList<>(
            List.of(
                new ArrayList<>(List.of(0, 3))
            )
        );
        tempItemData = new TempItemData("item.treasure_map", positions, "This is a treasure map!");
        tempItemDataList.add(tempItemData);

        return tempItemDataList;
    }

    public List<TempObstacleData> getTempObstacleData() {

        List<TempObstacleData> tempObstacleDataList = new ArrayList<>();

        List<List<Integer>> positions = new ArrayList<>(
            List.of(
                new ArrayList<>(List.of(5, 6)),
                new ArrayList<>(List.of(6, 8))
            )
        );
        TempObstacleData tempObstacleData = new TempObstacleData(positions, List.of("item.wooden_sword", "item.wooden_shield"));
        tempObstacleDataList.add(tempObstacleData);

        positions = new ArrayList<>(
            List.of(
                new ArrayList<>(List.of(8, 9)),
                new ArrayList<>(List.of(2, 7))
            )
        );
        tempObstacleData = new TempObstacleData(positions, List.of("item.wooden_sword"));
        tempObstacleDataList.add(tempObstacleData);

        return tempObstacleDataList;
    }


}
